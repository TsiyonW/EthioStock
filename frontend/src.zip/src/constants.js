export  const AUTH_TOKEN = 'auth-token'
export const STATE = 'state'